<?php
$koneksi = mysqli_connect("localhost", "root", "", "simkos");

// if (!$koneksi) {
//     echo "gagal terhubung ke database";
// } else {
//     echo "terhubung";
// }
