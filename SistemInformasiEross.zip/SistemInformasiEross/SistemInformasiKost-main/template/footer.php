</div>
<style>
    .copyright {
        padding: 50px;
    }
</style>
<footer style="margin-top:125px; margin-bottom:-30; color:white" class="sticky-footer bg-info">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Sistem Informasi Kost 2024 | eRoss</span>
        </div>
    </div>
</footer>
</body>