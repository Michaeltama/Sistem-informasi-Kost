bangunan utama img
